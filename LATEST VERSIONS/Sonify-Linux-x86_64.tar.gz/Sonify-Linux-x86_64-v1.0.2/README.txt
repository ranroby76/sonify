Sonify 1.0.2 for Linux (x86_64) - Fanan
================================================

Built on Ubuntu 24.04. To run it:

1. Unpack this folder anywhere you can write to (your home folder, say), and keep
   everything in it together: Sonify finds its Device Compiler, Plugin SDKs, LAME
   and knob gallery beside it.

2. Install what it runs on (Ubuntu 24.04 / Debian names):

   sudo apt install libpulse0 

3. For video (the Video lane, the Video window, the Live Show's videos), install VLC -
   Sonify plays video through the libvlc your machine has, and works without it:

   sudo apt install vlc

4. Run ./Sonify

Sonify keeps its settings in ~/.config/Fanan/Sonify.

For a menu entry: edit sonify.desktop so Exec= and Icon= give this folder's full paths
(Exec=/home/you/Sonify/Sonify, Icon=/home/you/Sonify/sonify_icon.png), then copy it to
~/.local/share/applications/.
